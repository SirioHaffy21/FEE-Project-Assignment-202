function addMoreQuestion() {
    const question = $('.question').first().clone();
    const listQuestion = $('.list-question');

    listQuestion.append(question);
}

$('.add-question').click(() => {
    addMoreQuestion();
});


function addMoreAnswer(buttonAdd) {
    const answer = `
    <div class="answer">
    
    <div class="input-group mb-3">
    
    <input type="text" class="form-control" name="answer" placeholder="Type your answer">

      </div>

      <p class="form-text col-4"></p>
      </div>`;

    const listAnswer = buttonAdd.closest('.list-answer');

    listAnswer.append($.parseHTML(answer)[1]);
}


function addError(input) {
    input.classList.remove('text-success');

    input.classList.add('text-danger');
}

function addSucces(input) {
    input.classList.remove('text-danger');

    input.classList.add('text-success');
}

function setText(inputText, message) {
    inputText.text(message);
}
var buttonAddAnswers = $('.add-answer');

for (const button in buttonAddAnswers) {
    $(button).click((e) => {
        const target = e.target.closest('.add-answer');
        if (target != null) {
            addMoreAnswer(target);
        }
    });
}

function isLength(input, minLength, maxLength) {
    if (input == null) {
        return false;
    }

    if (input.val().length > maxLength || input.val().length < minLength) {
        return false;
    }

    return true;
}


function validateLength(input, textError, errorMessage, validMessage, minLength, maxLength) {
    if (!isLength(input, minLength, maxLength)) {
        setText(textError, errorMessage);

        addError(textError[0]);
    } else {
        setText(textError, validMessage);

        addSucces(textError[0]);
    }
}

$('#create').submit((event) => {

    event.preventDefault();

    const namePoll = $('#namePoll').first();
    const questions = $("[name*='question']");
    const answers = $("[name*='answer']");


    validateLength(
        namePoll,
        namePoll.parent().find('.form-text').first(),
        'Length of name poll is greater than 3 and less than 255 character',
        'Name poll is valid',
        3,
        255
    );


    for (const question of questions) {
        validateLength(
            $(question),
            $(question).parent().find('.form-text').first(),
            'Length of question is greater than 3 and less than 255 character',
            'Question is valid',
            3,
            255
        );
    }


    for (const answer of answers) {
        validateLength(
            $(answer),
            $(answer).closest('.answer').find('.form-text').first(),
            'Length of answer is greater than 3 and less than 255 character',
            'Answer is valid',
            3,
            255
        );
    }
});